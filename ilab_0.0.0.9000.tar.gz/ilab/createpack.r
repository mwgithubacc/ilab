2+2

library(devtools)
getwd()
packageVersion("devtools")



create_package("/home/michael/rpack/ilab")

save(std1, file="/home/michael/rpack/ilab/data/std1.RData")
save(std2, file="/home/michael/rpack/ilab/data/std2.RData")
save(kam, file="/home/michael/rpack/ilab/data/chamomile.RData")
save(mel, file="/home/michael/rpack/ilab/data/melissa.RData")


kam


ls()

use_package("metRology")
install()



library(ilab)
ls()
data(chamomile)
ls()  
kam

use_r("plotmandelh")
use_test("plotmandelh")

load_all()
ls()

usethis::use_package("metRology" )
usethis::use_package("scales" )

plotmandelh(std1, "standard1", "lab")
plotmandelh(std2, "standard2", "lab")
plotmandelh(kam, "cham", "lab")
plotmandelh(mel, "mel", "lab")

library(metRology)
library(scales)


load_all()
ls()

usethis::use_package("metRology" )
usethis::use_package("scales" )

plotmandelh(std1, "standard1", "lab")
plotmandelh(std2, "standard2", "lab")
plotmandelh(kam, "cham", "lab")
plotmandelh(mel, "mel", "lab")

library(metRology)
library(scales)




library(roxygen2)
roxygen2::roxygenise()


create("/home/michael/rpack/ilab")
document()
build()
install.packages("/home/michael/rpack/ilab_0.0.0.9000.tar.gz")
library(ilab)
