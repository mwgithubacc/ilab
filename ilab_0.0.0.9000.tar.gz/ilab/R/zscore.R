#' calculate zscores by using labresults assigned values and sR
#'
#' 
#' 
#'
#'
#' @param labdata data.frame containing lab results
#' @param assign assigned mean calculated by fintithamp()
#' @param sr sR calculated by using the funktion sR()
#'
#' @return A data.frame of the same size as 'labdata' reporting zscores per lab an analyte.
#' @export

zscore <- function(labdata, assign, sr)
    {
derg <- as.data.frame(matrix(0,nrow=nrow(labdata),ncol=ncol(labdata)))
names(derg) <- names(labdata)
rownames(derg) <- rownames(labdata)
ll <- nrow(labdata)
        
for(i in 1:ll)
    {
derg[i,] <- (labdata[i,]-assign)/sr
}
derg
}
