#' Robust mean values calculated from the laboratory results, can be used as assigned values.
#'
#' 
#' This function calculates robust mean according to the Q-Hampel method.
#'
#'
#' @param werte Vector containing results of all labs for a given analyte.
#' @param sr sR calculated by using the funktion sR()
#'
#' @return A scalar reporting the robust mean.
#' @export

finithamp <- function(werte, sr)
{
df1 <- werte - 4.5*sr
df2 <- werte - 3*sr
df3 <- werte - 1.5*sr

df4 <- werte + 1.5*sr
df5 <- werte + 3*sr
df6 <- werte + 4.5*sr

adf <- c(df1,df2,df3,df4,df5,df6)
sadf <- sort(adf)
di1 <- abs(werte-median(werte))

num <- c(1:length(werte))


mi <- matrix(NA, ncol=length(werte),nrow=length(sadf))

for(i in 1:length(sadf))
    {
mi[i,] <- (werte - sadf[i]) / sr
}


mipsi <- matrix(NA, ncol=length(werte),nrow=length(sadf))

n1 <- which(mi >= 4.5)
if(length(n1)>0)
   {
       mipsi[n1] <- 0
       }
n2 <- which(mi < 4.5 & mi > 3)
if(length(n2)>0)
   {
       mipsi[n2] <- 4.5 - mi[n2]
       }
n3 <- which(mi <= 3 & mi > 1.5)
if(length(n3)>0)
   {
       mipsi[n3] <- 1.5 
       }
n4 <- which(mi <= 1.5 & mi > -1.5)
if(length(n4)>0)
   {
       mipsi[n4] <- mi[n4]
       }
n5 <- which(mi <= -1.5 & mi > -3)
if(length(n5)>0)
   {
       mipsi[n5] <- -1.5
       }
n6 <- which(mi <= -3 & mi > -4.5)
if(length(n6)>0)
   {
       mipsi[n6] <- -4.5 - mi[n6]
       }
n7 <- which(mi <= -4.5)
if(length(n7)>0)
   {
       mipsi[n7] <- 0
       }


etgb <- apply(mipsi,1,sum)
nex <- rep(NA,length(etgb))

k1 <- which(etgb==0)
if(length(k1)>0)
    {
        nex[k1] <- sadf[k1]
        }

k2 <- k1 - 1
k2 <- k2[which(k2>0)] 

if(length(k2)>0)
    {
        nex[k2] <- sadf[k2+1]
        }

ehk <- rep(NA,length(etgb))
for(i in 1:(length(etgb)-1))
    {
ehk[i] <- etgb[i]*etgb[i+1]
        }

k3 <- which(ehk<0)
if(length(k3)>0)
    {
nex[k3] <- sadf[k3]-etgb[k3]/((etgb[k3+1]-etgb[k3])/(sadf[k3+1]-sadf[k3]))
}



nex2 <- rep(NA,length(nex))
nex2 <- abs(nex-median(werte))

welcher <- which(nex2==min(nex2,na.rm=TRUE))
finithampel <- nex[welcher]
finithampel
}

