#' Sample homogeneity, determined according to ISO 13528
#'
#' Samples are considered as sufficiently homogenous, when at least the extended condition for homogeneity according to ISO 13528 point B.2.3 is fulfilled
#' 
#'
#'
#' @param d1 Data.frame containing duplicated analyses of samples.
#' 
#' @param SigmaPT acceptable level.
#'
#' @param unit Measurement Unit. Important for Horwitz calculation if SigmaPT is "H" 
#' 
#' @return A data.frame() object conaining calculated values and decisions about homogeneity.
#' @export

homogen_test <- function(d1, SigmaPT, unit)
    {
        if(unit=="g/kg")
    {
        funit <- 0.001
        }
if(unit=="mg/kg")
    {
        funit <- 0.000001
        }
if(unit=="µg/kg")
    {
        funit <- 0.000000001
        }
if(unit=="ng/kg")
    {
        funit <- 0.000000000001
        }


d1$mea <- apply(d1, 1, mean)
    d1$var <- apply(d1[, c(1, 2)], 1, var)
    w <- d1$mea
    MB <- var(w) * 2                                                   # MB = H17 
#print(MB, digits=11)
    MW <- sum(d1$var)/(length(c(d1$A, d1$B)) - length(d1$var))         # MW = I17
    F <- MB/MW                                                         #  F = J17
    al <- 0.05
    df1 <- length(d1$mea) - 1
    df2 <- (length(c(d1$A, d1$B)) - length(d1$var))
    Fc <- qf((1 - al), df1, df2)                                       # Fc = K17
    ent <- "NA"
    if (F < Fc) 
        ent <- "homogenous"
    if (F >= Fc) 
        ent <- "not homogenous"
    Swz <- mean(d1$var)                                                # Swz = H10
    print(var(w),digits=20)                                            # Var of mean
    print((Swz/2),digits=20)

    Ss <- sqrt(abs(var(d1$mea) - Swz/2))                               #  Ss = I10
if(var(w)-(Swz/2) < 0)
    {
        Ss  <- 0
        }
    Mges <- mean(c(d1$A, d1$B))                                        #Mges = B7
    Proz <- round(Ss * 100/Mges, 2)                                    #Proz = I11

if(is.numeric(SigmaPT))
   {
    SollS <- SigmaPT                                                   #SollS= B5
    Ssoll <- SollS * Mges/100                                          #Ssoll= J10
    Proz2 <- Ssoll * 100/Mges                                          #Proz2= J11
}

if(SigmaPT=="H")
    {
z1 <- Mges*funit
z2 <- z1^0.8495
z3 <- z2 * 0.02
z4 <- z3/funit
z5 <- round(z4,3)
#print(z5,digits=20)
SollS <- z5
Ssoll <- SollS                                          #Ssoll= J10
Proz2 <- Ssoll * 100/Mges                               #Proz2= J11

}
############################################################################
#if(SigmaPT=="tH")
#    {
#z1 <- Mges*funit
#z2 <- z1^0.8495
#z3 <- z2 * 0.02
#z4 <- z3/funit
#z5 <- round(z4,3)
#print(z5,digits=20)
#SollS <- z5
#Ssoll <- SollS                                          #Ssoll= J10
#Proz2 <- Ssoll * 100/Mges                               #Proz2= J11

#}

############################################################################


    NKDSso <- 0.3 * Ssoll                                              #NKDSso=K10 
    ent2 <- "NA"
    if (NKDSso > Ss)
        {
        ent2 <- "homogenous"
        }
    if (NKDSso <= Ss)
        {
        ent2 <- "not homogenous"
        }
    F1 <- qchisq(0.95, df1)/df1                                        # F1 = I14  
    F2 <- (qf(0.95, df1, (df1+1)) - 1)/2                               # F2 = J14
    wc <- sqrt(F1 * NKDSso * NKDSso + F2 * Swz)                        # wc = K14
    ent3 <- "NA"
    if (Ss < wc)
        {
        ent3 <- "homogenous"
        }
    if (Ss >= wc)
        {
        ent3 <- "not homogenous"
        }
    homFor <- (100 * Ss/0.3)/Mges
    homFor2 <- max(0, sqrt(abs(Ss^2 - F2 * Swz^2))/(0.09 * F1))
    derg <- data.frame(MSbetween = MB, MSwithin=MW, mean = Mges, stddev = Ss, testvalueF = F, 
        criticalF = Fc, dec1 = ent, Sw=Swz,NKDSso = NKDSso, Ssoll=Ssoll,Proz=Proz2,dec2 = ent2, 
        rootC = wc, F1=F1, F2=F2,dec3 = ent3, MinAccSigmaPT = homFor, MinAccSigmaPT2 = homFor2)
derg
        }
