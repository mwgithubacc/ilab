#' Plot of duplicated measures of the concentration of an analyte.
#'
#' 
#' Provides a first expression of measurement homogeneity
#'
#'
#' @param data Duplicated measures of an analyte.
#' @param name Name of the analyte
#'
#' @return Plot of duplicated measures of the analyte.
#' @export

plothom <- function(data, name)
    {
plot(data$A,ylim=c(0,max(data)),pch=16,col="blue",las=1,xlab="Sample",ylab=name)
points(data$B, pch=16,col="red")
}
