#' Sample homogeneity, determined according to ISO 13528
#'
#' Samples are considered as sufficiently homogenous, when at least the extended condition for homogeneity according to ISO 13528 point B.2.3 is fulfilled
#' 
#'
#'
#' @param d1 Data.frame containing duplicated analyses of samples.
#' 
#' @param SigmaPT acceptable level.
#'
#' @return A data.frame() object conaining calculated values and decisions about homogeneity.
#' @export

homogeneity_testingNew <- function(d1, SigmaPT)
    {
d1$mea <- apply(d1,1,mean)
d1$var <- apply(d1[,c(1,2)],1,var)

w <- d1$mea
MB <- var(w)*2 # calculation MS between
MW <- sum(d1$var)/ (length(c(d1$A,d1$B))-length(d1$var)) # MS within
F <- MB/MW
al <- 0.05
df1 <- length(d1$mea)-1
df2 <- (length(c(d1$A,d1$B))-length(d1$var))

# Calculation critical F value

Fc <- qf((1-al),df1,df2)

ent <- "NA"
if(F < Fc)
    ent <- "homogenous"
if(F >= Fc)
ent <- "not homogenous"


####################
Swz <- mean(d1$var)

Ss <- sqrt(abs(var(d1$mea) - Swz/2))

Mges <- mean(c(d1$A,d1$B))
Proz <- round(Ss*100/Mges,2)


SollS <- SigmaPT
Ssoll <- SollS*Mges/100


Proz2 <- Ssoll*100/Mges


NKDSso <- 0.3*Ssoll


ent2 <- "NA"
if(NKDSso > Ss)
    ent2 <- "homogenous"
if(NKDSso <= Ss)
ent2 <- "not homogenous"


F1 <- qchisq(0.95,df1)/df1    # I18
F2 <- (qf(0.95,df1,df1)-1)/2


wc <- sqrt(F1*NKDSso*NKDSso+F2*Swz)

ent3 <- "NA"
if(Ss < wc)
    ent3 <- "homogenous"
if(Ss >= wc)
ent3 <- "not homogenous"
# Calculation of minimal acceptable (for the current homogeneity) sigmaPT
homFor <-(100*Ss/0.3)/Mges
#homFor2 <- max(0,sqrt(Ss^2-F2*Swz^2)/(0.09*F1))
homFor2 <- max(0,sqrt(abs(Ss^2-F2*Swz^2))/(0.09*F1))


derg <- data.frame(
mean=Mges,
stddev=Ss,
testvalueF=F,
criticalF=Fc,
dec1=ent,
NKDSso=NKDSso,
dec2=ent2,
rootC=wc,
dec3=ent3,
MinAccSigmaPT=homFor,
MinAccSigmaPT2=homFor2)

derg
}
