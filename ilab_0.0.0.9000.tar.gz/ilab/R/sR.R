#' Reproducibility standard deviation according to Q method
#'
#' 
#' 
#'
#'
#' @param werte Vector containing results of all labs for a given analyte.
#' 
#' 
#'
#' @return Scalar representing the reproducibility standard deviation according to Q method.
#' @export

sR <- function(werte)
{

# remove missing values
werte <- na.omit(werte)

# sorted absolute difference of all pairs of values
co <- combn(werte, 2, diff)
sera <- sort(abs(co))

dd <- as.numeric(sera <= 0)
if(dd[1] == 1)
{
  dd10 <- sum(dd)
}
if(dd[1] == 0)
{
  dd10 <- 0
}

dd8 <- dd10/length(dd)

dm <- 0.25 + 0.75 * dd8


# n different differences

da <- data.frame(s1=c(NA, sera),s2=c(sera,NA))
da$dif <- da$s2-da$s1
da$equ <- rep(0,length(da$dif))
da$equ[which(da$dif<0.000001)] <- 1
da$Nr <- c(1:length(da$equ))

daA <- da[which(da$equ==0),c(2,5)]

daB <- daA[-length(daA[,1]),]

hh <- daB[,1]
hh <- hh[-length(hh)]

uni <- hh
er <- c(1,2,3)
for(i in 1:length(uni))
{
  er[i] <- max(   which(round(sera,6) <= round(uni[i],6))    )
  
}

di <- er

dkont <- data.frame(no=di,dd=uni)


H1 <- er/length(sera)


GG <- c(1,2,3)
for(i in 2:length(er))
{
  GG[i] <- er[i]+er[i-1]
}


GB <- GG
gb <- GB/(2*length(sera))

gb[1] <- 0.5*H1[1]


q <- dm

adif <- abs(gb-q)
daf <- data.frame(no=di, g1=gb, dif=adif, un=uni)
o1 <- order(daf$dif)

daso <- daf[o1,]
daso$un[c(1,2)]

dk5 <- daso$un[1]
dm4 <- q
dj5 <- daso$g1[1]
dk6 <- daso$un[2]
dj6 <- daso$g1[2]


dk7 <- dk5+(dm4-dj5)*(dk6-dk5)/(dj6-dj5)


sr <- dk7/(sqrt(2)*qnorm(0.625+0.375*dd8)) 
sr
}


