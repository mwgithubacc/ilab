#' Graphic compliance test according to Mandel
#'
#' Calculate Mandel’s k statistics for replicate observations and plot results. This function uses the mandel.k function of the metRology package.
#' 
#'
#'
#' @param df Data.frame containing lab results.
#' @param title Name of the matrix reported in df.
#' @param cha Name of the grouping variable containing the laboratories.
#'
#' @return A plot depicting the results per lab. Critical values for the 5 % and 1 % significance level are shown as yellow and red lines respectively.
#' @export

plotmandelk <- function (df, title, cha) 
{
    vars <- names(df)[which(names(df) != cha)]
    gg <- which(names(df) == cha)
    h <- metRology::mandel.k(df[, vars], g = df[, gg])
    dh <- dim(h)
    rs <- scales::rescale(c(1:dh[2]), to = c(0, 0.7))
    rr <- rep(rs, dim(h)[1])
    gco <- gray(rr)
    rr1 <- which(as.numeric(unlist(t(h))) > metRology::qmandelk(0.99, 
        dim(h)[1],n=2))
#    rr2 <- which(as.numeric(unlist(t(h))) < metRology::qmandelk((1 - 
#        0.995), dim(h)[1],n=2))
    rrr <- c(rr1)
    yy1 <- which(as.numeric(unlist(t(h))) > metRology::qmandelk(0.95, 
        dim(h)[1],n=2))
#    yy2 <- which(as.numeric(unlist(t(h))) < metRology::qmandelk((1 - 
#        0.975), dim(h)[1],n=2))
    yyy <- c(yy1)
    gco[yyy] <- "yellow"
    gco[rrr] <- "red"
    plot(h, las = 2, col = gco, main = paste0("Mandel's k statistics (within) for: ", 
        title), xlab = "Lab")
    legend("topleft", legend = names(h), col = gray(rs), lty = 1, 
        cex = 0.7, bg = "white", ncol = 7)
    abline(h = metRology::qmandelk(0.95, dim(h)[1],n=2), col = "yellow")
    abline(h = metRology::qmandelk(0.99, dim(h)[1],n=2), col = "red")
#    abline(h = metRology::qmandelk((1 - 0.975), dim(h)[1],n=2), col = "yellow")
#    abline(h = metRology::qmandelk((1 - 0.995), dim(h)[1],n=2), col = "red")
}
