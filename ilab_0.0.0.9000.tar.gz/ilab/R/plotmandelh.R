#' Graphic compliance test according to Mandel
#'
#' Calculate Mandel’s h statistics for replicate observations and plot results. This function uses the mandel.h function of the metRology package.
#' Mandel's statistics is used to check whether the results of the laboratories differed significantly from those of the other laboratories.
#'
#'
#' @param df Data.frame containing lab results.
#' @param title Name of the matrix reported in df.
#' @param cha Name of the grouping variable containing the laboratories.
#'
#' @return A plot depicting the results per lab. Critical values for the 5 % and 1 % significance level are shown as yellow and red lines respectively.
#' @export

plotmandelh <- function(df, title, cha)
{
# Berechnung von Mandel's h

vars <- names(df)[which(names(df)!=cha)]
gg <- which(names(df)==cha)



h <- metRology::mandel.h(df[,vars], g=df[,gg])



# Graustufen zur Unterscheidung der Analyten im Plot
dh <- dim(h)
rs <- scales::rescale(c(1:dh[2]), to=c(0,0.7))
rr <- rep(rs,dim(h)[1])
gco <- gray(rr)

# Identifizierung der Ergebnisse außerhalb 99%
rr1 <- which(as.numeric(unlist(t(h))) > metRology::qmandelh(0.995, dim(h)[1]))
rr2 <- which(as.numeric(unlist(t(h))) < metRology::qmandelh((1-0.995), dim(h)[1]))
rrr <- c(rr1,rr2)

# Identifizierung der Ergebnisse außerhalb 95%
yy1 <- which(as.numeric(unlist(t(h))) > metRology::qmandelh(0.975, dim(h)[1]))
yy2 <- which(as.numeric(unlist(t(h))) < metRology::qmandelh((1-0.975), dim(h)[1]))
yyy <- c(yy1,yy2)

# Färbung
gco[yyy] <- "yellow"
gco[rrr] <- "red"

# Plot, Legende und Erstellung der Grenzlinien
plot(h, las=2, col=gco, main = paste0("Mandel's h statistics for: ", title),xlab="Lab")
legend("topleft", legend=names(h), col=gray(rs), lty=1, cex=0.7, bg="white",ncol=7)
abline(h=metRology::qmandelh(0.975, dim(h)[1]),col="yellow")
abline(h=metRology::qmandelh(0.995, dim(h)[1]),col="red")
abline(h=metRology::qmandelh((1-0.975), dim(h)[1]),col="yellow")
abline(h=metRology::qmandelh((1-0.995), dim(h)[1]),col="red")
}
