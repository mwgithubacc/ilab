#' plot  zscores 
#'
#' 
#' 
#'
#'
#' @param data.frame with zscores
#'
#' @return A plot with zscores per lab and analyte.
#' @export

plotzscore <- function(zsc)
    {
werte <- as.matrix(zsc)
werte[which(is.na(werte))] <- 0
r1 <- which(werte > 3.5)
if(length(r1)>0)
{
  werte[r1] <- 3.5
}

r2 <- which(werte <  -3.5)
r2
if(length(r2)>0)
{
  werte[r2] = -3.5
}


par(las=1)
ylim <- ncol(werte)*7
xlim <- nrow(werte)*7
plot(NULL, xlim=c(1,xlim), ylim=c(1,ylim),axes=FALSE,ylab="Analyte", xlab="z score")

s1 <- seq(1,ylim,7)
s2 <- seq(1,xlim,7)
axis(2,at=s1,labels = colnames(werte))
axis(1,at=s2,labels = rownames(werte),las=2)


abline(h=s1, lty=3)
abline(v=s2, lty=3)


for(i in 1:nrow(werte))
    {
for(f in 1:ncol(werte))
    {
vx <- c(s2[i],s2[i],(s2[i]+werte[i,f]))
vy <- c((s1[f]-3),(s1[f]+3),s1[f])
co <- "blue"
if(werte[i,f] < -2) co <- "yellow"
if(werte[i,f] < -3) co <- "red"
if(werte[i,f] > 2) co <- "yellow"
if(werte[i,f] > 3) co <- "red"
polygon(x=vx,y=vy, col = co )
}
}
}


