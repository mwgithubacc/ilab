#install.packages("/home/michael/rpack/ilab/ilab_0.0.1.tar.gz")
library(ilab)
data(AT_Melissa)
data(Imn_chamomille)
data(Ren_chamomille)
ls()

# example data sets for homogeneity check
AT_Melissa
Imn_chamomille
Ren_chamomille

# help about function for homogeneity check
?homogeneity_testing
?homogeneity_testingNew

install.packages("outliers")
library(outliers)

ee <- vector("numeric",100)
for(i in 1:100)
    {
     x = rnorm(6)
     pp <- chisq.out.test(x)
ee[i] <- as.numeric(pp$p.value)
}
which(ee<0.05)
    
# to see function code just type name of function without arguments
homogeneity_testing
homogeneity_testingNew

str(AT_Melissa)
homogeneity_testing(AT_Melissa)
homogeneity_testingNew(AT_Melissa, 0.25)
homogeneity_testing(Imn_chamomille)
homogeneity_testingNew(Imn_chamomille, 0.25)
homogeneity_testing(Ren_chamomille)
homogeneity_testingNew(Ren_chamomille, 0.25)






homogeneity_testing(AT_Melissa)
homogeneity_testingNew(AT_Melissa, 0.25)

str(AT_Melissa)
AB <- data.frame(A=c(100.2,101.4,105,103),B=c(101.5,101.3,99,105)) 
AB

homogeneity_testing(AB)
homogeneity_testingNew(AB, 0.25)

d1 <- AB
   d1$mea <- apply(d1, 1, mean)
    d1$var <- apply(d1[, c(1, 2)], 1, var)
    w <- d1$mea
    MB <- var(w) * 2
    MW <- sum(d1$var)/(length(c(d1$A, d1$B)) - length(d1$var))
    F <- MB/MW
    al <- 0.05
    df1 <- length(d1$mea) - 1
    df2 <- (length(c(d1$A, d1$B)) - length(d1$var))
    Fc <- qf((1 - al), df1, df2)
    ent <- "NA"
    if (F < Fc) 
        ent <- "homogenous"
    if (F >= Fc) 
        ent <- "not homogenous"
    Swz <- mean(d1$var)
    Ss <- sqrt(var(d1$mea) - Swz/2)
    Mges <- mean(c(d1$A, d1$B))
    Proz <- round(Ss * 100/Mges, 2)
    SollS <- 25
    Ssoll <- SollS * Mges/100
    Proz2 <- Ssoll * 100/Mges
    NKDSso <- 0.3 * Ssoll
    ent2 <- "NA"
    if (NKDSso > Ss) 
        ent2 <- "homogenous"
    if (NKDSso <= Ss) 
        ent2 <- "not homogenous"
    F1 <- qchisq(0.95, df1)/df1
    F2 <- (qf(0.95, df1, df1) - 1)/2
    wc <- sqrt(F1 * NKDSso * NKDSso + F2 * Swz)
    ent3 <- "NA"
    if (Ss < wc) 
        ent3 <- "homogenous"
    if (Ss >= wc) 
        ent3 <- "not homogenous"
    derg <- data.frame(mean = Mges, stddev = Ss, testvalueF = F, 
        criticalF = Fc, dec1 = ent, NKDSso = NKDSso, dec2 = ent2, 
        rootC = wc, dec3 = ent3)
    derg




######### example data sets for proficiency test 
data(std1)
data(std2)
data(melissa)
data(chamomile)
ls()


mean(kam$Eu,na.rm=TRUE)

mel
# help for mandel test and plot
?plotmandelh

# to see function code just type name of function without arguments
plotmandelh

head(std1)

plotmandelh(std1, "Std1", "lab")
plotmandelh(std2, "Std2", "lab")
plotmandelh(kam, "chamomille", "lab")
plotmandelh(mel, "melissa", "lab")

###########################################

?sR

# apply sR function to all analytes in data set std1
sr1 <- apply(std1[,-1], 2, sR)

# show results
sr1


sr2 <- apply(std2[,-1], 2, sR)
sr3 <- apply(kam[,-1], 2, sR)
sr4 <- apply(mel[,-1], 2, sR)

# results
sr2
sr3
sr4


########################

##
?finithamp

nn <- ncol(std1)-1
zielA <- rep(0,nn)
for(a in 1:nn)
{
b <- a+1
werte <- std1[,b] 
werte <- as.numeric(na.omit(werte))
sr <- as.numeric(sr1[a])
zielA[a] <- round(finithamp(werte,sr),6)
}
round(zielA,2)
############################################
nn <- ncol(std2)-1
zielB <- rep(0,nn)
for(a in 1:nn)
{
b <- a+1
werte <- std2[,b] 
werte <- as.numeric(na.omit(werte))
sr <- as.numeric(sr2[a])
zielB[a] <- round(finithamp(werte,sr),6)
}
round(zielB,2)
#############################################
############################################
nn <- ncol(kam)-1
zielC <- rep(0,nn)
for(a in 1:nn)
{
b <- a+1
werte <- kam[,b] 
werte <- as.numeric(na.omit(werte))
sr <- as.numeric(sr3[a])
zielC[a] <- round(finithamp(werte,sr),6)
}
round(zielC,2)
#############################################
nn <- ncol(mel)-1
zielD <- rep(0,nn)
for(a in 1:nn)
{
b <- a+1
werte <- mel[,b] 
werte <- as.numeric(na.omit(werte))
sr <- as.numeric(sr4[a])
zielD[a] <- round(finithamp(werte,sr),6)
}
round(zielD,2)
#############################################

zielA
zielB
zielC
zielD

nw1 <- std1[,-1]
rownames(nw1) <- std1[,1]
nsr1 <- as.numeric(sr1)

nw2 <- std2[,-1]
rownames(nw2) <- std2[,1]
nsr2 <- as.numeric(sr2)

nw3 <- kam[,-1]
rownames(nw3) <- kam[,1]
nsr3 <- as.numeric(sr3)

nw4 <- mel[,-1]
rownames(nw4) <- mel[,1]
nsr4 <- as.numeric(sr4)



zs1 <- zscore(nw1,zielA,nsr1)
zs2 <- zscore(nw2,zielB,nsr2)
zs3 <- zscore(nw3,zielC,nsr3)
zs4 <- zscore(nw4,zielD,nsr4)


###################
?plotzscore
plotzscore(zs1)
plotzscore(zs2)
plotzscore(zs3)
plotzscore(zs4)

